import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ack',
  templateUrl: './ack.component.html',
  styleUrls: ['./ack.component.css']
})
export class AckComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
