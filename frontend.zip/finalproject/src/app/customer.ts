export class Customer{
    
    constructor(public customerid:String = "", public accountholdername:String="",public overdraft:String="",public clearbalance:number=0){

    }
}